// Mostrar sección seleccionada
function mostrarSeccion(seccion) {
    const secciones = document.querySelectorAll('.seccion');
    secciones.forEach(s => s.style.display = 'none');
    document.getElementById(seccion).style.display = 'flex';
}

// Mostrar ventana de bienvenida al cargar la página
window.addEventListener('load', () => {
    mostrarSeccion('bienvenida');
});

// Enviar formulario de reserva
document.getElementById('formReserva').addEventListener('submit', function(e) {
    e.preventDefault();
    const nombre = this.nombre.value;
    const destino = this.destino.value;
    const fecha = this.fecha.value;
    document.getElementById('mensajeReserva').textContent =
        `Reserva simulada para ${nombre} a ${destino} el ${fecha}`;
    this.reset();
});
